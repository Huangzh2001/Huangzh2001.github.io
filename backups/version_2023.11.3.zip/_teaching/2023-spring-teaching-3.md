---
title: "Teaching experience 3"
collection: teaching
type: "Abstract Algebra"
permalink: /teaching/2023-spring-teaching-3
venue: "University 1, Department"
date: 2023-01-01
location: "City, Country"
---

This is a description of a teaching experience. You can use markdown like any other post.

Here is the handout:[Abstract Algebra](http://Huangzh2001.github.io/files/AbAl.pdf)
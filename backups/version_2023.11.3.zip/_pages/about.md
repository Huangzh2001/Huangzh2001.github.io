---
permalink: /
title: "About me"
excerpt: "About me"
author_profile: true
redirect_from: 
  - /about/
  - /about.html
---

<div align=center><img title="" src="../images/HZH-QCHT.jpg" alt="" data-align="center" width="451"></div>
  
Here is **Zihang Huang (Harry, 黄梓航)**. 

I graduated from the School of Mathematics of Sun Yat-sen University with a bachelor's degree. Currently, I am continuing my master's studies at Sun Yat-sen University.

If you are interested in any aspect of me, I would love to chat and collaborate, please email me at huangzh253@mail2.sysu.edu.cn. Or if you are willing, you can add my WeChat account, but please include your name and purpose:

<div align=center><img title="" src="../images/Wechat.jpg" alt="" data-align="center" width="265"></div>

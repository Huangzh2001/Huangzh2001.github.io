---
title: 'Lie group and liealgebra notes'
collection: notes
date: 2023-04-12
permalink: /notes/2023-04-12-lieAlgebra-notes1
---

This is a study notes of lie group and lie algebra, which briefly introduces the definition of Lie algebra and  Lie groups, and their relations(this is to be continue).

Here is my notes: [Lie group and liealgebra notes](https://nalydz.github.io/files/lie algebra notes-cn.pdf).



